import * as React from 'react';
import * as ReactDOM from 'react-dom';
import Hello from "./components/App";
//import "./scss/style.scss";

ReactDOM.render( 
    <Hello name="Abhay" />,   
    document.getElementById('app'));
